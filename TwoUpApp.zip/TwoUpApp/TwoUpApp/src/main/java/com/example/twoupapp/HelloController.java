package com.example.twoupapp;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.canvas.GraphicsContext;
import javafx.application.Application;
import javafx.animation.AnimationTimer;

public class HelloController {

    @FXML
    private Button btnHeadsHeads;

    @FXML
    private Button btnHeadsTails;

    @FXML
    private Button btnTailsTails;

    @FXML
    private Pane containerTwoUp;

    @FXML
    private ImageView imageResult;

    @FXML
    private TextField nameInputField;

    @FXML
    private Label textCoinFlipResult;

    @FXML
    void buttonClickedHeadTails(ActionEvent event) {

    }

    @FXML
    void buttonClickedHeadsHeads(ActionEvent event) {

    }

    @FXML
    void buttonClickedTailsTails(ActionEvent event) {

    }

    @FXML
    void nameInputAction(ActionEvent event) {

    }

}
