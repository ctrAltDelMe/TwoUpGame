package com.example.twoupapp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.stage.Stage;

import java.io.IOException;

public abstract class Main extends Application {


    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Main.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 700);
        Group root = new Group();
        Canvas canvas = new Canvas(512,512);
        root.getChildren().add(canvas);
        stage.setTitle("Two Up Game by Stephen Zanker");
        stage.setScene(scene);
        stage.show();
}
    public static void main(String[] args) {
        launch();
    }

}